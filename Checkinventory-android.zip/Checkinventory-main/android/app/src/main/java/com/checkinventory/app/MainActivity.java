package com.checkinventory.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
